#!/bin/python3
from datetime import datetime
import json
import requests
import sys
from fabulous import utils,image


api_url="https://api.catboys.com/img"

response = requests.get(api_url)

info = response.json()
imagen = info["url"]

print("url de la imagen"+imagen)
print(datetime.now())


images= requests.get(imagen).content

image_name="gatoboy.jpeg"
with open(image_name, "wb") as handler:
	handler.write(images)

img = image.Image(image_name)

print(img)

