import pygsheets
import pandas as pd
import xmltodict
import sys

sheet_name="EnBuscaDePac"
if len(sys.argv)>1:
	sheet_name = sys.argv[1]

archivo= open("enemy_xml","r")
datos = xmltodict.parse(archivo.read())
archivo.close()

# Create empty dataframe
enemies = datos["enemies"]["enemy"]

df_enemies=pd.DataFrame(enemies, columns=["name", "damage", "health"])

archivo1=open("weapons.xml","r")
datos1=xmltodict.parse(archivo1.read())
archivo1.close()

weapons = datos1["weapons"]["weapon"]
df_weapons=pd.DataFrame(weapons, columns=["weapon_name", "type", "pdamage", "level", "uses"])
gc = pygsheets.authorize(service_file='/home/enti/claves/token.json')

#open the google spreadsheet (where 'PY to Gsheet Test' is the name of my sheet)

try:
	sh = gc.open(sheet_name)
except pygsheets.exceptions.SpreadsheetNotFound:
	respuesta= input("La pagina que quieres crear no existe, quieres crearla? Y/n")
	if respuesta.lower()=="n":
		quit()
	else:
		sh = gc.create(sheet_name)
		sh.share("ian.nogueira@enti.cat",role="writer")


wks = None
try:
	wks = sh.worksheet_by_title("enemies")
except pygsheets.exceptions.WorksheetNotFound:

	print("La sheet enemies no existe, se esta creando")

	wks=s[0]
	wks.title="enemies"


#update the first sheet with df, starting at cell B2. 
wks.clear()
wks.set_dataframe(df_enemies,(1,1))
col="C"
row=2
cells=[]

for hp in df_enemies["health"]:
	cell=wks.cell(col+str(row))
	if int(hp) < 50:	
		cell.color=(1,0,0,0)
		
	elif int(hp) < 80:
		cell.color=(1,1,0,0)
		
	else:
		cell.color=(0,1,0,1)
	cells.append(cell)
	row +=1

wks.update_cells_prop(cell_list=cells)

try:
	wks=sh.worksheet_by_title("weapons")
except pygsheets.exceptions.WorksheetNotFound:
	print("La sheet weapons no existe, se esta creando")
	wks = sh.add_worksheet("weapons")

wks.set_dataframe(df_weapons,(1,1))
